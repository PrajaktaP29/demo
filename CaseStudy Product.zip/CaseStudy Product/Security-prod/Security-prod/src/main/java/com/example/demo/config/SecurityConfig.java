package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfig {

	private final JwtRequestFilter jwtRequestFilter;

    // Constructor injection of the JwtRequestFilter
    public SecurityConfig(JwtRequestFilter jwtRequestFilter) {
        this.jwtRequestFilter = jwtRequestFilter;
    }

    // Expose AuthenticationManager as a Bean
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);

        // In-memory authentication example (replace with actual authentication mechanism)
        authenticationManagerBuilder.inMemoryAuthentication()
                .withUser("admin").password("{noop}adminpass").roles("ADMIN")
                .and()
                .withUser("user").password("{noop}userpass").roles("USER");

        return authenticationManagerBuilder.build();
    }

    // Security filter chain that configures access to different endpoints
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
            .authorizeRequests()
                // Allow access to public routes (e.g., login)
                .requestMatchers("/api/auth/**").permitAll()  // Public login endpoint
             // User routes
                .requestMatchers("/products/user/**").hasRole("USER") 
                // Admin routes
                .requestMatchers("/products/admin/**").hasRole("ADMIN")  // Only ADMIN can access these
                
                  // Only USER can access these
                // Default, any other endpoint requires authentication
                .anyRequest().authenticated()
            .and()
                // Add JWT filter for authorization in every request
                .addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
