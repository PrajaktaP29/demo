package com.example.demo.client;
// Import the Product entity (not in Security Service, just for FeignClient)


import com.productservice.model.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Optional;

@FeignClient(name = "PRODUCT")  // URL of your Product Service
public interface ProductFeignClient {
	
	   @GetMapping("/products/user/getall")
	    List<Product> getAllProducts();  // Pass JWT token

	    @GetMapping("/products/user/getproduct/{prodId}")
	    Optional<Product> getProductById(@PathVariable Long prodId);  // Pass JWT token

	    @GetMapping("/products/user/getproduct/{prodname}")
	    List<Product> searchProductsByName(@PathVariable("prodname") String prodname);  // Pass JWT token

	    @PostMapping("/products/admin/add")
	    Product addOrUpdateProduct(@RequestBody Product product);  // Pass JWT token

	    @PutMapping("/products/admin/update/{prodId}")
	    Product updateProduct(@PathVariable Long prodId, @RequestBody Product updatedProduct);  // Pass JWT token

	    @DeleteMapping("/products/admin/delete/{prodId}")
	    void deleteProduct(@PathVariable Long prodId);  // Pass JWT token
    
}
