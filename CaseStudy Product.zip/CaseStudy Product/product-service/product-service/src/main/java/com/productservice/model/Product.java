package com.productservice.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
//import jakarta.validation.constraints.Min;
//import jakarta.validation.constraints.NotNull;
//import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "products")
public class Product {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long prodId;
	   
//	    @NotNull(message = "Product name cannot be null")
//	    @Size(min = 1, message = "Product name must have at least 1 character")
	    private String prodname;
	    
//	    @NotNull(message = "Description cannot be null")
	    private String description;
	    
//	    @NotNull(message = "Product price cannot be null")
//	    @Min(value = 0, message = "Product price must be greater than or equal to 0")
	    private Double prodprice;
	    
//	    @NotNull(message = "Quantity in stock cannot be null")
//	    @Min(value = 0, message = "Quantity in stock must be greater than or equal to 0")
	    private Integer quantityInStock;

}
