package com.productservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.productservice.model.Product;
import com.productservice.service.ProductService;

//import jakarta.validation.Valid;

@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
    private ProductService productService;

	@GetMapping("/user/getall")
	@PreAuthorize("hasRole('ROLE_USER')")
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

	@GetMapping("/user/getproduct/{prodId}")
	@PreAuthorize("hasRole('ROLE_USER')")
    public Product getProductById(@PathVariable Long prodId) {
        return productService.getProductById(prodId);
    }

	@GetMapping("/user/getproduct/{prodname}")
	@PreAuthorize("hasRole('ROLE_USER')")
    public List<Product> searchProducts(@RequestParam String prodname) {
        return productService.searchProductsByName(prodname);
    }

	@PostMapping("/admin/add")
	@PreAuthorize("hasRole('ROLE_ADMIN')")
    public Product addProduct(@RequestBody Product product) {
        return productService.addProduct(product);
    }

	 @PutMapping("/admin/update/{prodId}")
	 @PreAuthorize("hasRole('ROLE_ADMIN')")
    public Product updateProduct(@PathVariable Long prodId,@RequestBody Product product) {
        return productService.updateProduct(prodId, product);
    }

	 @DeleteMapping("/admin/delete/{prodId}")
	 @PreAuthorize("hasRole('ROLE_ADMIN')")
    public void deleteProduct(@PathVariable Long prodId) {
        productService.deleteProduct(prodId);
    }


}
