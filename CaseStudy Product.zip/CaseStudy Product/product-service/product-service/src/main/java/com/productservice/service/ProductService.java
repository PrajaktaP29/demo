package com.productservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.productservice.exception.ProductNotFoundException;
import com.productservice.model.Product;
import com.productservice.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
    private ProductRepository productRepository;

	public List<Product> getAllProducts() {
		
		return productRepository.findAll();
	}

	public Product getProductById(Long prodId) {
		
		return productRepository.findById(prodId).orElseThrow();
	}

	public List<Product> searchProductsByName(String prodname) {
		
		return productRepository.findByProdnameContaining(prodname);
	}

	public Product addProduct(Product product) {
		
		return productRepository.save(product);
	}

	public Product updateProduct(Long prodId, Product product) {
		
		Product products = productRepository.findById(prodId).orElseThrow();
		products.setProdname(product.getProdname());
		products.setDescription(product.getDescription());
		products.setProdprice(product.getProdprice());
		products.setQuantityInStock(product.getQuantityInStock());
		return productRepository.save(product);
	}

	public Product deleteProduct(Long prodId) {
		Product product = productRepository.findById(prodId).orElseThrow();
		productRepository.delete(product);
		return product;
		
		
	}

	

}
